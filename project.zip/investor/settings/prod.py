from .base import *

DEBUG = False


ALLOWED_HOSTS = ["eventmanagement-y16a.onrender.com"]




