from django.apps import AppConfig


class EventPortalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'event_portal'
